/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "usart.h"
#include "gpio.h"
#include "fsmc.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "fpgahandle.h"
#include "stdio.h"
#include "math.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
#include "sys.h"//��Ҫͷ�ļ�����
#include "delay.h"
#include "lcd.h"//��ʾ
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
static uint8_t vpp_choose = 1;
static uint8_t phase_choose = 0;
static uint32_t stm32_fre_data[3] = {0};
static uint8_t cnt = 0;
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
uint16_t fpga_16bits = 0;
uint8_t fpga_get = 0;
uint8_t flag = 0;
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
uint8_t FPGA_data[8];
uint16_t rx_vpp = 0;
uint16_t rx_phase = 0;
uint32_t rx_fre = 0;
void FPGA_Handle(uint8_t data)	//����Openmv������������ 
{

	static int state = 0;
	if(state==0 && data == 0x7b)
	{	
		state=1;
	}
	else if(state==1)
	{
		state=2;
		FPGA_data[0]=data;
		rx_vpp = data;
	}
	else if(state==2)
	{
		state=3;
		FPGA_data[1]=data;
		rx_vpp <<= 8;
		rx_vpp = rx_vpp | data;
	}
	else if(state==3)
	{
		state=4;
		FPGA_data[2]=data;
		rx_phase = data;
	}
		else if(state==4)
	{
		state=5;
		FPGA_data[3]=data;
		rx_phase <<= 8;
		rx_phase = rx_phase | data;
	}
		else if(state==5)
	{
		state=6;
		FPGA_data[4]=data;
		rx_fre = data;
	}
	else if(state==6)
	{
		state=7;
		FPGA_data[5]=data;
		rx_fre <<= 7;
		rx_fre = rx_fre | data;
	}
	else if(state==7)
	{
		state=8;
		FPGA_data[6]=data;
		rx_fre <<= 8;
		rx_fre = rx_fre | data;
	}
		else if(state==8)
	{
		state=0;
		FPGA_data[7]=data;
		rx_fre <<= 8;
		rx_fre = rx_fre | data;
		flag = 1;
	}

}
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
void USART2_IRQHandler(void)
{
//  HAL_GPIO_TogglePin(GPIOF, GPIO_PIN_9);
	if((__HAL_UART_GET_FLAG(&huart2,UART_FLAG_RXNE)!=RESET)) 		//���������ж�
	{
		__HAL_UART_CLEAR_FLAG(&huart2,UART_FLAG_RXNE);		//����жϱ�־	
		fpga_get=USART2->DR ;		//��DR�Ĵ�����ȡ��һ������
		FPGA_Handle(fpga_get);	
	}    
	HAL_UART_IRQHandler(&huart2);
}
void USART3_IRQHandler(void)
{
//  HAL_GPIO_TogglePin(GPIOF, GPIO_PIN_9);
	if((__HAL_UART_GET_FLAG(&huart3,UART_FLAG_RXNE)!=RESET)) 		//���������ж�
	{
		__HAL_UART_CLEAR_FLAG(&huart3,UART_FLAG_RXNE);		//����жϱ�־	
				HAL_GPIO_WritePin(LED_GPIO_Port,LED_Pin,GPIO_PIN_RESET);
		fpga_get=USART3->DR ;		//��DR�Ĵ�����ȡ��һ������
		stm32_fre_data[cnt] = rece_32_data(fpga_get);	
		if(stm32_fre_data[cnt]>0)
			cnt++;
	}    
	HAL_UART_IRQHandler(&huart3);
}
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
__weak void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin);
//�����ⲿ�ж�
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	if(GPIO_Pin==KEY_WK_Pin)
	{
		HAL_Delay(100);
		if(HAL_GPIO_ReadPin(KEY_WK_GPIO_Port,KEY_WK_Pin)==1)
		{
			vpp_choose = 1;
			phase_choose= 0;
			char* temp1[12] = "Vpp / fre";
			lcd_show_string (10,0,200,32,32,*temp1,RED);
			HAL_GPIO_TogglePin(LED_GPIO_Port,LED_Pin);
		}
	}
	if(GPIO_Pin==KEY0_Pin)
	{
		HAL_Delay(100);
		if(HAL_GPIO_ReadPin(KEY0_GPIO_Port,KEY0_Pin)==0)
		{
			vpp_choose = 0;
			phase_choose = 1;
			char* temp1[12] = "Phase / fre";
			lcd_show_string (10,0,200,32,32,*temp1,RED);
			HAL_GPIO_TogglePin(LED_GPIO_Port,LED_Pin);
		}
	}
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
	
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();
  MX_FSMC_Init();
  MX_USART3_UART_Init();
  /* USER CODE BEGIN 2 */
			//Uart2���ڽ����ж�
	__HAL_UART_ENABLE(&huart2);
	__HAL_UART_ENABLE_IT(&huart2,UART_IT_RXNE);//ʹ�ܽ����ж�
	__HAL_UART_CLEAR_FLAG(&huart2,UART_FLAG_RXNE);  
	lcd_init();//��ʾ
	lcd_display_dir(1);
	lcd_clear(WHITE);
	HAL_Delay(500);
	my_lcd();
		//Uart2���ڽ����ж�
	__HAL_UART_ENABLE(&huart3);
	__HAL_UART_ENABLE_IT(&huart3,UART_IT_RXNE);//ʹ�ܽ����ж�
	__HAL_UART_CLEAR_FLAG(&huart3,UART_FLAG_RXNE);  

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
	float get_vpp = 0;
	double get_phase = 0;
	static double phase_max = 0;
	static double phase_sta = 0;
	double get_fre = 0;
	static double fre_sta = 0;
	int vpp_one = 0;
	int vpp_two = 0;
	int vpp_thrid = 0;
  while (1)
  {
		if(cnt == 3)
		{
			__HAL_UART_DISABLE(&huart3);
			__HAL_UART_DISABLE_IT(&huart3,UART_IT_RXNE);
	
			for (int i=0; i<3; i++)
			{
				printf("%d\r\n",stm32_fre_data[i]);
			}
			cnt=0;
			my_lcd_coord();
		}
		else
		{
			if(flag)
			{
				//stm32_fre_data[cnt]	0 ��ʼ		1 ����	 2 ����
				get_vpp = ((float)rx_vpp /1024) * 5;
				get_fre = ((double)rx_fre /pow(2,32))* 125000000;
				get_phase = (float)rx_phase *360 * (get_fre/50000000);
	//		printf("HEX: %#x  %#x  %#x \r\n",rx_vpp,rx_phase,rx_fre);
				//�ж�
				if(get_fre >= 5000-stm32_fre_data[2] && get_fre <= 5000+stm32_fre_data[2])
				{
					vpp_one = get_vpp;
//					printf("a%f",get_vpp);
				}
				else if(get_fre >= 10000-stm32_fre_data[2] && get_fre <= 10000+stm32_fre_data[2])
				{
					vpp_two = get_vpp;
//					printf("b%f",get_vpp);
				}
				else if(get_fre >= 30000-stm32_fre_data[2] && get_fre <= 30000+stm32_fre_data[2])
				{
					vpp_thrid = get_vpp;
					printf("a%d,b%d,c%d",vpp_one,vpp_two,vpp_thrid);
					if(vpp_one>vpp_two && vpp_one>vpp_thrid)
					{
						char* temp8[8] = "Low Pass";	
						lcd_show_string (350,10,100,24,24,*temp8,RED);
					}
					else if(vpp_two>vpp_one && vpp_two>vpp_thrid)
					{
						char* temp8[9] = "Band Pass";	
						lcd_show_string (350,10,100,24,24,*temp8,RED);
					}
					else if(vpp_thrid>vpp_two && vpp_thrid>vpp_one)
					{
						char* temp8[9] = "High Pass";	
						lcd_show_string (350,10,100,24,24,*temp8,RED);
					}
					else 
					{
						char* temp8[9] = "No Pass";	
						lcd_show_string (400,10,40,24,24,*temp8,RED);
					}
				}
				//����
				uint32_t fre_step = get_fre - fre_sta;
				if(fre_step >= stm32_fre_data[2] - stm32_fre_data[2]/5   &&   fre_step <=1000+stm32_fre_data[2]/5 )
				{
					if(vpp_choose ==1 && phase_choose == 0)
					{
						my_lcd_draw_vpp(get_vpp,get_fre);
					}
					else if(vpp_choose ==0 && phase_choose == 1 )
					{
						if(get_phase>5)
						{
							phase_max = (phase_sta > get_phase) ? phase_sta : get_phase;
							printf("%f  %lf  %lf \r\n",get_vpp,phase_sta,get_fre);
						}
						if(phase_max > phase_sta)
							phase_sta += 10; 
						my_lcd_draw_phase(phase_sta,get_fre);		
					}
				}
				else if(get_fre >= stm32_fre_data[1])
				{
						phase_sta = 0;
						lcd_clear(WHITE);
						my_lcd();
						my_lcd_coord();

						 vpp_one = 0;
						 vpp_two = 0;
						 vpp_thrid = 0;
				}
				fre_sta = get_fre;
				flag = 0;
			}
		}

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 168;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
/* �ض���fputc����, printf�������ջ�ͨ������fputc����ַ��������� */
int fputc(int ch, FILE *f)
{
    while ((USART1->SR & 0X40) == 0);               /* �ȴ���һ���ַ�������� */
    USART1->DR = (uint8_t)ch;                       /* ��Ҫ���͵��ַ� ch д�뵽DR�Ĵ��� */
    return ch;
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

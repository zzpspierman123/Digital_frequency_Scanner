#ifndef _ALL_TESTS_H_
#define _ALL_TESTS_H_

/*--------------------------------------------------------------------------------*/
/* Declare Test Groups */
/*--------------------------------------------------------------------------------*/
JTEST_DECLARE_GROUP(all_tests);

#endif /* _ALL_TESTS_H_ */
